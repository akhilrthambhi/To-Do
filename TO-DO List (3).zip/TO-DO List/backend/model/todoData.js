const mongoose=require('mongoose');

const ToDoSchema = new mongoose.Schema({
    description: String,
    status: { type: String, enum: ['completed', 'ongoing'], default: 'ongoing' },
  });
  