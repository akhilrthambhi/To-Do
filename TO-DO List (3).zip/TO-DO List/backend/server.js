const express = require('express');
const cors = require('cors');
const app = new express();
app.use(cors())

require('dotenv').config()
const PORT = process.env.PORT

const todoRoutes = require('./routes/todoroutes')

app.use('/todo',todoRoutes)
require('./db/connection');


app.listen(PORT,()=>{
    console.log(`Server is running on PORT ${PORT}`);
})